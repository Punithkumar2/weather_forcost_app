const haze = require('../images/haze.png');
const rainy = require('../images/rainy.png');
const snowflake = require('../images/snowflake.png');
const sunny = require('../images/sun.png');

export {haze,rainy,snowflake,sunny};